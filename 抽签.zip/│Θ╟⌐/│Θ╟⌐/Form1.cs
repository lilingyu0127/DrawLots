﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Data.OleDb;
using System.IO;

namespace 抽签
{
    public partial class Form1 : Form
    {
        public int Number1 = 0;//单次抽取
        public int Number2 = 0;//总共抽取
        public int Number3 = 0;//目前抽取
        public int Number4 = 0;//名单总数
        public Form1()
        {
            InitializeComponent();
            lbl提醒.Hide();
            lbl确定.Hide();
            lbl导入名单.Hide();
        }
        //确定数量
        private void button4_Click(object sender, EventArgs e)
        {
            Number1 = int.Parse(num每次输出.Value.ToString());
            Number2 = int.Parse(num需求总数.Value.ToString());
            if (Number2 < Number1)
                MessageBox.Show("抽取总数不得小于每次抽取数！");
            else
            {
                lbl每次输出.Text = Number1.ToString();
                lbl需求总数.Text = Number2.ToString();
            }
        }
        //重置结果
        private void button2_Click(object sender, EventArgs e)
        {
            lst抽签结果.Items.Clear();
            textBox1.Clear();
            lbl每次输出.Text = "";
            lbl目前结果.Text = "";
            lbl需求总数.Text = "";
            Number1 = 0;
            Number2 = 0;
            Number3 = 0;
            //enable();
        }
        //重置名单
        private void button3_Click(object sender, EventArgs e)
        {
            Number1 = 0;
            Number2 = 0;
            Number3 = 0;
            Number4 = 0;
            lst抽签结果.Items.Clear();
            lst抽签名单.Items.Clear();
            lbl参与人数.Text = "";
            lbl每次输出.Text = "";
            lbl目前结果.Text = "";
            lbl需求总数.Text = "";
            textBox2.Clear();
            textBox1.Clear();
            textBox3.Clear();
            //enable();
        }
        //删除选中
        private void button5_Click_1(object sender, EventArgs e)
        {
            if (lst抽签名单.SelectedIndex >= 0)
            {
                while (lst抽签名单.SelectedIndex != -1)
                    lst抽签名单.Items.Remove(lst抽签名单.SelectedItem);
                Number4 = lst抽签名单.Items.Count;
                lbl参与人数.Text = Number4.ToString();
            }
            else
                MessageBox.Show("当前并未选择任何项");
        }
        //移除抽签结果选中
        private void button10_Click(object sender, EventArgs e)
        {
            if (lst抽签结果.SelectedIndex >= 0)
            {
                if (lst抽签结果.SelectedIndex >= 0)
                {
                    while (lst抽签结果.SelectedIndex != -1)
                        lst抽签结果.Items.Remove(lst抽签结果.SelectedItem);
                    Number3 = lst抽签结果.Items.Count;
                    lbl目前结果.Text = Number3.ToString();
                }
            }
            else
                MessageBox.Show("当前并未选择任何项");
        }
        //插入抽签名单
        private void button7_Click(object sender, EventArgs e)
        {
            string insert = this.textBox2.Text.Trim().ToString();
            int index = lst抽签名单.SelectedIndex;
            //判断人员是否已经添加过
            if (textBox2.Text == "")
                MessageBox.Show("输入不能为空！");
            else if (!lst抽签名单.Items.Contains(insert))
            {
                if(lst抽签名单.SelectedItems.Count>1)
                    MessageBox.Show("请确定插入位置！");
                else
                {
                    if (index >= 0)
                    {
                        index++;
                        lst抽签名单.Items.Insert(index, insert);
                        lst抽签名单.SelectedItem = null;
                        lst抽签名单.SelectedItem = lst抽签名单.Items[index];
                    }
                    else

                    {
                        lst抽签名单.Items.Add(insert);
                        lst抽签名单.SelectedIndex = lst抽签名单.Items.Count - 1;
                    }

                    textBox2.Clear();
                    Number4 = lst抽签名单.Items.Count;
                    lbl参与人数.Text = Number4.ToString();
                }
              
            }
            else
            {
                MessageBox.Show("该选项已经添加过，无法重复添加！");
            }
        }
        //禁用按钮函数
        public void ban()
        {
            checkBox1.Enabled = false;
            button4.Enabled = false;
            btn导入名单.Enabled = false;
            btn插入.Enabled = false;
            btn删除选中.Enabled = false;
            num每次输出.Enabled = false;
            num需求总数.Enabled = false;
            lbl提醒.Show();
            lbl确定.Show();
            lbl导入名单.Show();
        }
        //启用按钮函数
        public void enable()
        {
            checkBox1.Enabled = true;
            button4.Enabled = true;
            btn导入名单.Enabled = true;
            btn插入.Enabled = true;
            btn删除选中.Enabled = true;
            num每次输出.Enabled = true;
            num需求总数.Enabled = true;
            lbl提醒.Hide();
            lbl确定.Hide();
            lbl导入名单.Hide();
        }
        //开始抽签
        private void button1_Click(object sender, EventArgs e)
        {
            Number4 = lst抽签名单.Items.Count;
            lbl参与人数.Text = Number4.ToString();
            if (Number4 < 1)
                MessageBox.Show("请确认抽签名单！");
            else if (Number1 < 1)
                MessageBox.Show("请确认抽签数量！");
            else if (Number2 < 1)
                MessageBox.Show("请确认抽签总数！");
            else if (Number3 >= Number2)
                MessageBox.Show("已经抽完了！");
            else
            {
                if (checkBox1.Checked)
                {

                        //ban();
                        int m;//一次抽签的数量累计
                        Random ran = new Random();
                        int RandKey;
                        for (m = 1; m <= Number1 & Number3 < Number2;)
                        {
                            RandKey = ran.Next(0, Number4);
                            lst抽签结果.Items.Add(lst抽签名单.Items[RandKey]);

                            m++;
                            Number3++;
                        }
                        lbl目前结果.Text = Number3.ToString();
                    
                }
                else
                {
                    if (Number2 > Number4)
                        MessageBox.Show("输出总数不得大于参与人数！");
                    else
                    {
                        //ban();
                        int m;//一次抽签的数量累计
                        Random ran = new Random();
                        int RandKey;
                        for (m = 1; m <= Number1 & Number3 < Number2;)
                        {

                            RandKey = ran.Next(0, Number4);
                            if (!lst抽签结果.Items.Contains(lst抽签名单.Items[RandKey]))
                            {
                                lst抽签结果.Items.Add(lst抽签名单.Items[RandKey]);
                                
                                m++;
                                Number3++;
                            }
                        }
                        lbl目前结果.Text = Number3.ToString();
                    }
                }
            }

        }
        //导入
        private void button8_Click(object sender, EventArgs e)
        {                        ;
            int index = lst抽签名单.Items.Count;
            ReadTxtToLst(lst抽签名单);
            Number4 = lst抽签名单.Items.Count;
            lbl参与人数.Text = Number4.ToString();
            lst抽签名单.SelectedIndex = lst抽签名单.Items.Count - 1;
        }

        //导出
        private void button9_Click(object sender, EventArgs e)
        {
            SaveLstToTxt(lst抽签结果);
            Number3 = lst抽签结果.Items.Count;
            lbl目前结果.Text = Number3.ToString();
        }

        //按键输入名单
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.button7_Click(sender, e);
            }
            if (e.KeyChar == (char)13) e.Handled = true;
        }
        //搜索结果
        private void btn搜索结果_Click(object sender, EventArgs e)
        {
            int index = lst抽签结果.Items.IndexOf(textBox1.Text);
            lst抽签结果.TopIndex = index;
            lst抽签结果.SelectedIndex = index;
        }
        //按键搜索结果
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btn搜索结果_Click(sender, e);
            }
            if (e.KeyChar == (char)13) e.Handled = true;
        }
        //搜索名单
        private void btn搜索名单_Click(object sender, EventArgs e)
        {
            int index = lst抽签名单.Items.IndexOf(textBox3.Text);
            lst抽签名单.TopIndex = index;
            lst抽签名单.SelectedIndex = index;
        }
        //按键搜索名单
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btn搜索名单_Click(sender, e);
            }
            if (e.KeyChar == (char)13) e.Handled = true;
        }
        //按键删除名单
        private void lst抽签名单_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                this.button5_Click_1(sender, e);
        }
        //案件删除结果
        private void lst抽签结果_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                this.button10_Click(sender, e);
        }

        //导出名单函数
        private void SaveLstToTxt(ListBox lst)
        {
            sfd.Filter = "(*.txt)|*.txt";
            sfd.FileName = "";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string sPath = sfd.FileName;
                FileStream fs = new FileStream(sPath, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs, Encoding.UTF8);
                int iCount = lst.Items.Count - 1;
                for (int i = 0; i <= iCount; i++)
                {
                    sw.WriteLine(lst.Items[i].ToString());
                }
                sw.Flush();
                sw.Close();
                fs.Close();
            }

        }
        //导入名单函数
        private void ReadTxtToLst(ListBox lst)
        {
            ofd.Filter = "(*.txt)|*.txt";
            ofd.FileName = "";
            int delete = 0;
            int sum = 0;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string sPath = ofd.FileName;
                string s = string.Empty;
                FileStream fs = new FileStream(sPath, FileMode.Open);
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                
                while ((s = sr.ReadLine()) != null)
                {
                    if(s.Trim()!="")
                    {
                        if (!lst抽签名单.Items.Contains(s))
                        {
                            s = s.ToString();
                            lst.Items.Add(s);
                            sum++;
                        }
                        else
                            delete++;
                    }
                    
                }
                if (delete > 0)
                    MessageBox.Show("已插入" + sum + "个数据，" + delete + "个因为重复被剔除！");
                sr.Close();
                fs.Close();
            }
        }
        //生成连续整数
        private void btn生成整数_Click(object sender, EventArgs e)
        {
            int min= int.Parse(num起始.Value.ToString());
            int max= int.Parse(num结束.Value.ToString());
            int delete = 0;
            int sum = 0;
            if (min > max)
                MessageBox.Show("起始值不得大于终值！");
            else
            {
                for (; min <= max; min++)
                {
                    if (!lst抽签名单.Items.Contains(min.ToString()))
                    {
                        lst抽签名单.Items.Add(min.ToString());
                        sum++;
                    }
                    else
                        delete++;
                }

                Number4 = lst抽签名单.Items.Count;
                lbl参与人数.Text = Number4.ToString();                
                lst抽签名单.SelectedIndex = lst抽签名单.Items.Count - 1;
                if (delete > 0)
                    MessageBox.Show("已插入" + sum + "个整数，" + delete + "个因为重复被剔除！");
            }          
        }
//改名颜色变化
        private void lbl标题_MouseDown(object sender, MouseEventArgs e)
        {
            lbl标题.ForeColor = Color.FromArgb(0, 70, 140);
        }

        private void lbl标题_MouseUp(object sender, MouseEventArgs e)
        {
            lbl标题.ForeColor = SystemColors.ControlText;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("①如何添加抽签名单：\r* 可选择手动输入、自动生成整数或从文本文件（.txt）按行导入；\r* 不允许有重复项或空白项，自动生成或导入时会被自动剔除；\r\r②导出名单为txt格式，每个数据按行导出；\r\r③如何删除选项：\r* 选中后点击“删除”或按“delete”键；\r* 可多选；\r\r④什么是“可重复”？\r* 新抽出的数据可与已抽出的数据相同；", "使用说明");
        }
    }
}
