﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 抽签
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string peopleText = this.textBox2.Text.Trim().ToString();
            //获取listbox1的对象
            ListBox list1 = this.listBox1;
            //判断人员是否已经添加过
            if (textBox2.Text == "")
                MessageBox.Show("输入不能为空！");
            else if (!list1.Items.Contains(peopleText))
            {
                list1.Items.Add(peopleText);
                textBox2.Clear();
            }
            else
            {
                MessageBox.Show("该人员已经添加过，无法重复添加！");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                
            }
        }
    }
}
