﻿namespace 抽签
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl标题 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lst抽签结果 = new System.Windows.Forms.ListBox();
            this.num每次输出 = new System.Windows.Forms.NumericUpDown();
            this.lst抽签名单 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn插入 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl参与人数 = new System.Windows.Forms.Label();
            this.lbl每次输出 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn重置名单 = new System.Windows.Forms.Button();
            this.btn删除选中 = new System.Windows.Forms.Button();
            this.btn导入名单 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl目前结果 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button10 = new System.Windows.Forms.Button();
            this.num需求总数 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl需求总数 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl确定 = new System.Windows.Forms.Label();
            this.lbl导入名单 = new System.Windows.Forms.Label();
            this.lbl提醒 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn搜索结果 = new System.Windows.Forms.Button();
            this.btn搜索名单 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.num起始 = new System.Windows.Forms.NumericUpDown();
            this.num结束 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn生成整数 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.num每次输出)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num需求总数)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num起始)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num结束)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl标题
            // 
            this.lbl标题.AutoSize = true;
            this.lbl标题.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbl标题.Font = new System.Drawing.Font("黑体", 25F);
            this.lbl标题.Location = new System.Drawing.Point(352, 16);
            this.lbl标题.Name = "lbl标题";
            this.lbl标题.Size = new System.Drawing.Size(151, 34);
            this.lbl标题.TabIndex = 0;
            this.lbl标题.Text = "抽签程序";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("黑体", 18F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(15, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 35);
            this.button1.TabIndex = 1;
            this.button1.Text = "开始抽签";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Brown;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("黑体", 18F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(15, 143);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 35);
            this.button2.TabIndex = 4;
            this.button2.Text = "重置结果";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 15F);
            this.label3.Location = new System.Drawing.Point(17, 393);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "每次输出：";
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("黑体", 15F);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(116, 431);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(68, 30);
            this.button4.TabIndex = 8;
            this.button4.Text = "确定";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("黑体", 15F);
            this.label4.Location = new System.Drawing.Point(17, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "总参与人数：";
            // 
            // lst抽签结果
            // 
            this.lst抽签结果.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lst抽签结果.Font = new System.Drawing.Font("黑体", 15F);
            this.lst抽签结果.FormattingEnabled = true;
            this.lst抽签结果.ItemHeight = 20;
            this.lst抽签结果.Location = new System.Drawing.Point(200, 97);
            this.lst抽签结果.Name = "lst抽签结果";
            this.lst抽签结果.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lst抽签结果.Size = new System.Drawing.Size(248, 364);
            this.lst抽签结果.TabIndex = 13;
            this.lst抽签结果.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lst抽签结果_KeyUp);
            // 
            // num每次输出
            // 
            this.num每次输出.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.num每次输出.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num每次输出.Font = new System.Drawing.Font("黑体", 15F);
            this.num每次输出.Location = new System.Drawing.Point(116, 389);
            this.num每次输出.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.num每次输出.Name = "num每次输出";
            this.num每次输出.Size = new System.Drawing.Size(68, 30);
            this.num每次输出.TabIndex = 15;
            this.num每次输出.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lst抽签名单
            // 
            this.lst抽签名单.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lst抽签名单.Font = new System.Drawing.Font("黑体", 15F);
            this.lst抽签名单.FormattingEnabled = true;
            this.lst抽签名单.ItemHeight = 20;
            this.lst抽签名单.Location = new System.Drawing.Point(645, 99);
            this.lst抽签名单.Name = "lst抽签名单";
            this.lst抽签名单.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lst抽签名单.Size = new System.Drawing.Size(248, 364);
            this.lst抽签名单.TabIndex = 16;
            this.lst抽签名单.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lst抽签名单_KeyUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("黑体", 15F);
            this.label5.Location = new System.Drawing.Point(725, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 17;
            this.label5.Text = "抽签名单";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("黑体", 15F);
            this.label6.Location = new System.Drawing.Point(197, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(249, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "抽签结果目前共计      个";
            // 
            // btn插入
            // 
            this.btn插入.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn插入.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn插入.Font = new System.Drawing.Font("黑体", 18F);
            this.btn插入.Location = new System.Drawing.Point(465, 170);
            this.btn插入.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.btn插入.Name = "btn插入";
            this.btn插入.Size = new System.Drawing.Size(80, 35);
            this.btn插入.TabIndex = 21;
            this.btn插入.Text = "插入";
            this.btn插入.UseVisualStyleBackColor = true;
            this.btn插入.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("黑体", 20F);
            this.textBox2.Location = new System.Drawing.Point(465, 126);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(163, 38);
            this.textBox2.TabIndex = 20;
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 15F);
            this.label2.Location = new System.Drawing.Point(461, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "请输入抽签名单：";
            // 
            // lbl参与人数
            // 
            this.lbl参与人数.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl参与人数.AutoSize = true;
            this.lbl参与人数.Font = new System.Drawing.Font("黑体", 15F);
            this.lbl参与人数.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl参与人数.Location = new System.Drawing.Point(134, 257);
            this.lbl参与人数.Name = "lbl参与人数";
            this.lbl参与人数.Size = new System.Drawing.Size(0, 20);
            this.lbl参与人数.TabIndex = 23;
            // 
            // lbl每次输出
            // 
            this.lbl每次输出.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl每次输出.AutoSize = true;
            this.lbl每次输出.Font = new System.Drawing.Font("黑体", 15F);
            this.lbl每次输出.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl每次输出.Location = new System.Drawing.Point(134, 318);
            this.lbl每次输出.Name = "lbl每次输出";
            this.lbl每次输出.Size = new System.Drawing.Size(0, 20);
            this.lbl每次输出.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("黑体", 15F);
            this.label9.Location = new System.Drawing.Point(17, 316);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "每次输出量：";
            // 
            // btn重置名单
            // 
            this.btn重置名单.BackColor = System.Drawing.Color.Brown;
            this.btn重置名单.FlatAppearance.BorderSize = 0;
            this.btn重置名单.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn重置名单.Font = new System.Drawing.Font("黑体", 18F);
            this.btn重置名单.ForeColor = System.Drawing.Color.White;
            this.btn重置名单.Location = new System.Drawing.Point(465, 214);
            this.btn重置名单.Name = "btn重置名单";
            this.btn重置名单.Size = new System.Drawing.Size(163, 35);
            this.btn重置名单.TabIndex = 26;
            this.btn重置名单.Text = "重置名单";
            this.btn重置名单.UseVisualStyleBackColor = false;
            this.btn重置名单.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn删除选中
            // 
            this.btn删除选中.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn删除选中.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn删除选中.Font = new System.Drawing.Font("黑体", 18F);
            this.btn删除选中.Location = new System.Drawing.Point(548, 170);
            this.btn删除选中.Name = "btn删除选中";
            this.btn删除选中.Size = new System.Drawing.Size(80, 35);
            this.btn删除选中.TabIndex = 27;
            this.btn删除选中.Text = "删除";
            this.btn删除选中.UseVisualStyleBackColor = true;
            this.btn删除选中.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // btn导入名单
            // 
            this.btn导入名单.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn导入名单.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.btn导入名单.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn导入名单.FlatAppearance.BorderSize = 0;
            this.btn导入名单.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn导入名单.Font = new System.Drawing.Font("黑体", 18F);
            this.btn导入名单.ForeColor = System.Drawing.Color.White;
            this.btn导入名单.Location = new System.Drawing.Point(465, 385);
            this.btn导入名单.Name = "btn导入名单";
            this.btn导入名单.Size = new System.Drawing.Size(163, 33);
            this.btn导入名单.TabIndex = 28;
            this.btn导入名单.Text = "导入名单.txt";
            this.btn导入名单.UseVisualStyleBackColor = false;
            this.btn导入名单.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("黑体", 18F);
            this.button9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button9.Location = new System.Drawing.Point(463, 428);
            this.button9.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(165, 33);
            this.button9.TabIndex = 29;
            this.button9.Text = "导出结果.txt";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(293, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 51);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // lbl目前结果
            // 
            this.lbl目前结果.AutoSize = true;
            this.lbl目前结果.Font = new System.Drawing.Font("黑体", 15F);
            this.lbl目前结果.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl目前结果.Location = new System.Drawing.Point(372, 74);
            this.lbl目前结果.Name = "lbl目前结果";
            this.lbl目前结果.Size = new System.Drawing.Size(0, 20);
            this.lbl目前结果.TabIndex = 31;
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("黑体", 15F);
            this.checkBox1.Location = new System.Drawing.Point(21, 435);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(88, 24);
            this.checkBox1.TabIndex = 32;
            this.checkBox1.Text = "可重复";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("黑体", 18F);
            this.button10.Location = new System.Drawing.Point(15, 189);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(169, 38);
            this.button10.TabIndex = 33;
            this.button10.Text = "移除选中";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // num需求总数
            // 
            this.num需求总数.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.num需求总数.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num需求总数.Font = new System.Drawing.Font("黑体", 15F);
            this.num需求总数.Location = new System.Drawing.Point(116, 354);
            this.num需求总数.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.num需求总数.Name = "num需求总数";
            this.num需求总数.Size = new System.Drawing.Size(68, 30);
            this.num需求总数.TabIndex = 35;
            this.num需求总数.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("黑体", 15F);
            this.label11.Location = new System.Drawing.Point(17, 358);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 20);
            this.label11.TabIndex = 34;
            this.label11.Text = "总计输出：";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Silver;
            this.label12.Location = new System.Drawing.Point(19, 479);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(173, 12);
            this.label12.TabIndex = 36;
            this.label12.Text = "DEVELOPED BY LINGYU FOR MCTU";
            // 
            // lbl需求总数
            // 
            this.lbl需求总数.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl需求总数.AutoSize = true;
            this.lbl需求总数.Font = new System.Drawing.Font("黑体", 15F);
            this.lbl需求总数.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl需求总数.Location = new System.Drawing.Point(134, 287);
            this.lbl需求总数.Name = "lbl需求总数";
            this.lbl需求总数.Size = new System.Drawing.Size(0, 20);
            this.lbl需求总数.TabIndex = 38;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("黑体", 15F);
            this.label14.Location = new System.Drawing.Point(17, 285);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 20);
            this.label14.TabIndex = 37;
            this.label14.Text = "需求输出量：";
            // 
            // lbl确定
            // 
            this.lbl确定.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl确定.AutoSize = true;
            this.lbl确定.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl确定.Font = new System.Drawing.Font("黑体", 15F);
            this.lbl确定.ForeColor = System.Drawing.Color.Silver;
            this.lbl确定.Location = new System.Drawing.Point(125, 436);
            this.lbl确定.Name = "lbl确定";
            this.lbl确定.Size = new System.Drawing.Size(49, 20);
            this.lbl确定.TabIndex = 39;
            this.lbl确定.Text = "确定";
            // 
            // lbl导入名单
            // 
            this.lbl导入名单.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl导入名单.AutoSize = true;
            this.lbl导入名单.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lbl导入名单.Font = new System.Drawing.Font("黑体", 18F);
            this.lbl导入名单.ForeColor = System.Drawing.Color.Silver;
            this.lbl导入名单.Location = new System.Drawing.Point(495, 390);
            this.lbl导入名单.Name = "lbl导入名单";
            this.lbl导入名单.Size = new System.Drawing.Size(106, 24);
            this.lbl导入名单.TabIndex = 41;
            this.lbl导入名单.Text = "导入名单";
            // 
            // lbl提醒
            // 
            this.lbl提醒.AutoSize = true;
            this.lbl提醒.BackColor = System.Drawing.Color.White;
            this.lbl提醒.Font = new System.Drawing.Font("黑体", 12F);
            this.lbl提醒.ForeColor = System.Drawing.Color.Silver;
            this.lbl提醒.Location = new System.Drawing.Point(18, 74);
            this.lbl提醒.Name = "lbl提醒";
            this.lbl提醒.Size = new System.Drawing.Size(184, 16);
            this.lbl提醒.TabIndex = 42;
            this.lbl提醒.Text = "重置后可更改其他设置！";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.Font = new System.Drawing.Font("黑体", 12F);
            this.textBox1.Location = new System.Drawing.Point(200, 467);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(163, 26);
            this.textBox1.TabIndex = 43;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // btn搜索结果
            // 
            this.btn搜索结果.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn搜索结果.BackColor = System.Drawing.Color.White;
            this.btn搜索结果.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn搜索结果.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn搜索结果.Font = new System.Drawing.Font("黑体", 12F);
            this.btn搜索结果.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn搜索结果.Location = new System.Drawing.Point(370, 467);
            this.btn搜索结果.Name = "btn搜索结果";
            this.btn搜索结果.Size = new System.Drawing.Size(77, 26);
            this.btn搜索结果.TabIndex = 44;
            this.btn搜索结果.Text = "搜索";
            this.btn搜索结果.UseVisualStyleBackColor = true;
            this.btn搜索结果.Click += new System.EventHandler(this.btn搜索结果_Click);
            // 
            // btn搜索名单
            // 
            this.btn搜索名单.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn搜索名单.BackColor = System.Drawing.Color.White;
            this.btn搜索名单.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn搜索名单.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn搜索名单.Font = new System.Drawing.Font("黑体", 12F);
            this.btn搜索名单.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn搜索名单.Location = new System.Drawing.Point(815, 467);
            this.btn搜索名单.Name = "btn搜索名单";
            this.btn搜索名单.Size = new System.Drawing.Size(77, 26);
            this.btn搜索名单.TabIndex = 46;
            this.btn搜索名单.Text = "搜索";
            this.btn搜索名单.UseVisualStyleBackColor = true;
            this.btn搜索名单.Click += new System.EventHandler(this.btn搜索名单_Click);
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox3.Font = new System.Drawing.Font("黑体", 12F);
            this.textBox3.Location = new System.Drawing.Point(645, 467);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(163, 26);
            this.textBox3.TabIndex = 45;
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // ofd
            // 
            this.ofd.FileName = "openFileDialog1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("黑体", 15F);
            this.label7.Location = new System.Drawing.Point(461, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(189, 20);
            this.label7.TabIndex = 47;
            this.label7.Text = "自动导入连续整数：";
            // 
            // num起始
            // 
            this.num起始.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num起始.Font = new System.Drawing.Font("黑体", 15F);
            this.num起始.Location = new System.Drawing.Point(492, 292);
            this.num起始.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.num起始.Name = "num起始";
            this.num起始.Size = new System.Drawing.Size(90, 30);
            this.num起始.TabIndex = 49;
            this.num起始.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // num结束
            // 
            this.num结束.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num结束.Font = new System.Drawing.Font("黑体", 15F);
            this.num结束.Location = new System.Drawing.Point(492, 326);
            this.num结束.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.num结束.Name = "num结束";
            this.num结束.Size = new System.Drawing.Size(90, 30);
            this.num结束.TabIndex = 48;
            this.num结束.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("黑体", 15F);
            this.label8.Location = new System.Drawing.Point(461, 297);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 20);
            this.label8.TabIndex = 50;
            this.label8.Text = "始";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("黑体", 15F);
            this.label10.Location = new System.Drawing.Point(461, 331);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 20);
            this.label10.TabIndex = 51;
            this.label10.Text = "终";
            // 
            // btn生成整数
            // 
            this.btn生成整数.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.btn生成整数.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn生成整数.FlatAppearance.BorderSize = 0;
            this.btn生成整数.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn生成整数.Font = new System.Drawing.Font("黑体", 18F);
            this.btn生成整数.ForeColor = System.Drawing.Color.White;
            this.btn生成整数.Location = new System.Drawing.Point(591, 292);
            this.btn生成整数.Name = "btn生成整数";
            this.btn生成整数.Size = new System.Drawing.Size(37, 64);
            this.btn生成整数.TabIndex = 52;
            this.btn生成整数.Text = "生成";
            this.btn生成整数.UseVisualStyleBackColor = false;
            this.btn生成整数.Click += new System.EventHandler(this.btn生成整数_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("黑体", 15F);
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.linkLabel1.Location = new System.Drawing.Point(461, 473);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(169, 20);
            this.linkLabel1.TabIndex = 53;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "抽签程序使用说明";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(918, 500);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.btn生成整数);
            this.Controls.Add(this.num起始);
            this.Controls.Add(this.num结束);
            this.Controls.Add(this.btn搜索名单);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.btn搜索结果);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl提醒);
            this.Controls.Add(this.lbl导入名单);
            this.Controls.Add(this.lbl确定);
            this.Controls.Add(this.lbl需求总数);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.num需求总数);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.lbl目前结果);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.btn导入名单);
            this.Controls.Add(this.btn删除选中);
            this.Controls.Add(this.btn重置名单);
            this.Controls.Add(this.lbl每次输出);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbl参与人数);
            this.Controls.Add(this.btn插入);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lst抽签名单);
            this.Controls.Add(this.num每次输出);
            this.Controls.Add(this.lst抽签结果);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl标题);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label10);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(934, 539);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "医学部抽签程序";
            ((System.ComponentModel.ISupportInitialize)(this.num每次输出)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num需求总数)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num起始)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num结束)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl标题;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lst抽签结果;
        private System.Windows.Forms.NumericUpDown num每次输出;
        private System.Windows.Forms.ListBox lst抽签名单;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn插入;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl参与人数;
        private System.Windows.Forms.Label lbl每次输出;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn重置名单;
        private System.Windows.Forms.Button btn删除选中;
        private System.Windows.Forms.Button btn导入名单;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl目前结果;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.NumericUpDown num需求总数;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl需求总数;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl确定;
        private System.Windows.Forms.Label lbl导入名单;
        private System.Windows.Forms.Label lbl提醒;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn搜索结果;
        private System.Windows.Forms.Button btn搜索名单;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.OpenFileDialog ofd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown num起始;
        private System.Windows.Forms.NumericUpDown num结束;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn生成整数;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

